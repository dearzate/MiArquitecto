rm -rf outp
mkdir outp
javac -sourcepath ./com/NativeGallery -Xlint:-deprecation -Xlint:deprecation -classpath "./classes.jar:./" -bootclasspath "/Library/Android/sdk/platforms/android-23/android.jar" -d outp \
./com/NativeGallery/UnityProxyActivity.java ./com/NativeGallery/AndroidGallery.java 

cd outp
javap -s com.NativeGallery.AndroidGallery com.NativeGallery.UnityProxyActivity 
jar cvfM AndroidGallery.jar com
cd ..
mv ./outp/AndroidGallery.jar ../Assets/Tastybits/NativeGallery/Native/Android/AndroidGallery.jar

