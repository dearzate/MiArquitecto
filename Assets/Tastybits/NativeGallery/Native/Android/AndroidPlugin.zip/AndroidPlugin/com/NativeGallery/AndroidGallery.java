package com.NativeGallery;
import com.unity3d.player.UnityPlayerActivity;
import com.unity3d.player.UnityPlayer;
import android.util.Log;
import android.content.Context;
import android.widget.Toast;
import java.lang.reflect.Field;
import java.lang.reflect.*;
import java.util.Set;
import java.util.List;
//import android.hardware.Camera.AutoFocusCallback;
import android.hardware.SensorManager;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorEvent;
//import android.hardware.Camera.PreviewCallback;
import java.util.ArrayList;
import android.content.Intent;
import java.util.Arrays;
import java.lang.Class.*;


@SuppressWarnings("deprecation")
public class AndroidGallery  {  
	
	public static String OpenGallery_Callback=null;
	
    
	// 
	public static void OpenGalleryFireCallback( boolean ok, boolean cancelled, String path ) {
		/*
		   	NSDictionary * dictRet = [[NSDictionary alloc] initWithObjectsAndKeys: lastImageUri, @"path", @"true", @"succeeded", @"false", @"cancelled", nil];
        	NSString* strRet = [dictRet bv_jsonStringWithPrettyPrint:TRUE];
        	UnitySendMessage( [self.callbackName UTF8String], "CallDelegateFromNative", [strRet UTF8String] );
		*/
		if( AndroidGallery.OpenGallery_Callback == null ) {
			Log.d("Unity", "NativeGallery: ignored invoking Native callback" );
			return;		
		}
		String sPath = path;
		String sCancel = cancelled ? "true" : "false";
		String sOk = ok ? "true" : "false";
		String jsonRet = "{ \"path\":\""+sPath+"\", \"succeeded\":\""+sOk+"\", \"cancelled\":\""+sCancel+"\" }";
		
		String tmp = OpenGallery_Callback;
		OpenGallery_Callback = null; // Clear it.
		
		Log.d("Unity", "NativeGallery: Invoking callback on object : " + tmp + " with json = " + jsonRet );
		UnityPlayer.UnitySendMessage( tmp, "CallDelegateFromNative", jsonRet );
	}
	
    static public void OpenGallery( String cbId ) {
    	if( cbId == null || cbId == "" ) {
    		Log.d("Unity","NativeGallery: No callback object id given" );
    		return;
    	}
    	OpenGallery_Callback = cbId;
		Intent i = new Intent(UnityPlayer.currentActivity,com.NativeGallery.UnityProxyActivity.class);
		UnityPlayer.currentActivity.startActivity(i);
	}
  
}


