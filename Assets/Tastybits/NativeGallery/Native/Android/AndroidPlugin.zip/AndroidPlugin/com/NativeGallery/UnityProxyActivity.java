package com.NativeGallery;
import com.unity3d.player.UnityPlayer;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Images.ImageColumns;
import android.provider.MediaStore.Images.ImageColumns.*;
import android.database.Cursor;
import android.view.KeyEvent;


public class UnityProxyActivity extends Activity {
    static final String ACTION_FINISH = "com.Tastybits.ACTION_FINISH";
    private BroadcastReceiver broadcastReceiver;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

		Log.d("Unity", "ProxyActivity: OnCreate");
		
        /*broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.d( "Unity", "UnityProxyActivity: Finish broadcast was received");
                if (!UnityProxyActivity.this.isFinishing()) {
                    finish();
                }
            }
        };
        registerReceiver(broadcastReceiver, new IntentFilter(ACTION_FINISH));*/
        
      	// Start a Gallery.....   
        Intent intent = new Intent();
 		intent.setType("image/*");
 		intent.setAction( Intent.ACTION_PICK );
		startActivityForResult( intent, 100 );
    }
    
   // public static 

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if( AndroidGallery.OpenGallery_Callback!=null ) 
	        AndroidGallery.OpenGalleryFireCallback( /*ok*/false, /*cancelled*/true, "" );
        //unregisterReceiver(broadcastReceiver);
    }
    
    private String getRealPathFromURI(Uri contentURI) {
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            return contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(idx);
        }
    }

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if ((keyCode == KeyEvent.KEYCODE_BACK)) {
	        if( AndroidGallery.OpenGallery_Callback!=null ) 
		  		AndroidGallery.OpenGalleryFireCallback( /*ok*/false, /*cancelled*/true, "" );
	        finish();
	    }
	    return super.onKeyDown(keyCode, event);
	}
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d( "Unity", "UnityProxyActivity: onActivityResult(" + requestCode + ", " + resultCode + ", " + data);
		
		this.finish();
		
		if( requestCode == 100 ) {
			
			try {
				
				Uri uri = data.getData();
				String spath = getRealPathFromURI(uri); //uri.getPath();
				if( AndroidGallery.OpenGallery_Callback!=null ) 
		        	AndroidGallery.OpenGalleryFireCallback( /*ok*/true, /*cancelled*/false, "file://"+spath );
			} catch( Exception e ) {
				Log.d("Unity","UnityProxyActivity - caught unknown exception");
				if( AndroidGallery.OpenGallery_Callback!=null ) 
		        	AndroidGallery.OpenGalleryFireCallback( /*ok*/false, /*cancelled*/false, "" );
			}
			
		} else {
			Log.d("Unity", "NativeGallery: Unknown requestCode " + requestCode );	
		}
		 
       
    }
}


